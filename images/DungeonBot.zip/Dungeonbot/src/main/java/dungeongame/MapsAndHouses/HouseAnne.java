package dungeongame.MapsAndHouses;

public class HouseAnne {
}
